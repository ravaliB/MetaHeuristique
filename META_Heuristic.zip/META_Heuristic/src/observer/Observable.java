package observer;

import java.awt.Point;
import java.util.HashMap;
import java.util.List;

import common.Pair;

public interface Observable {
	public void addObserver(Observer obs);
	public void removeObserver();
	public void notifyObserver(HashMap<Integer, Point> sites, List<Pair<Point, Point>> links, double temperature, double cost);
}
