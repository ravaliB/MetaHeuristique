package observer;

import java.awt.Point;
import java.util.HashMap;
import java.util.List;

import common.Pair;

public interface Observer {
	public void update(HashMap<Integer, Point> map, List<Pair<Point, Point>> linksMap, double temperature, double cost);
}
