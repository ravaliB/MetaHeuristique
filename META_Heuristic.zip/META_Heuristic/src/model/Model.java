package model;

import java.awt.Point;
import java.util.HashMap;

import common.Pair;

public class Model extends AbstractModel {
	public void run() {
		this.isRunning = true;

		
		links.add(new Pair<Point, Point>(sites.get(0), sites.get(1)));
		links.add(new Pair<Point, Point>(sites.get(0), sites.get(5)));

		links.add(new Pair<Point, Point>(sites.get(1), sites.get(6)));
		links.add(new Pair<Point, Point>(sites.get(1), sites.get(2)));

		links.add(new Pair<Point, Point>(sites.get(2), sites.get(3)));
		links.add(new Pair<Point, Point>(sites.get(2), sites.get(7)));

		links.add(new Pair<Point, Point>(sites.get(3), sites.get(8)));
		links.add(new Pair<Point, Point>(sites.get(3), sites.get(4)));

		links.add(new Pair<Point, Point>(sites.get(4), sites.get(9)));

		links.add(new Pair<Point, Point>(sites.get(5), sites.get(6)));
		links.add(new Pair<Point, Point>(sites.get(5), sites.get(10)));
		
		links.add(new Pair<Point, Point>(sites.get(6), sites.get(7)));
		links.add(new Pair<Point, Point>(sites.get(6), sites.get(11)));

		links.add(new Pair<Point, Point>(sites.get(7), sites.get(8)));
		links.add(new Pair<Point, Point>(sites.get(7), sites.get(12)));

		links.add(new Pair<Point, Point>(sites.get(8), sites.get(9)));
		links.add(new Pair<Point, Point>(sites.get(8), sites.get(13)));

		links.add(new Pair<Point, Point>(sites.get(9), sites.get(14)));

		links.add(new Pair<Point, Point>(sites.get(10), sites.get(11)));
		links.add(new Pair<Point, Point>(sites.get(10), sites.get(15)));

		links.add(new Pair<Point, Point>(sites.get(11), sites.get(12)));
		links.add(new Pair<Point, Point>(sites.get(11), sites.get(16)));

		links.add(new Pair<Point, Point>(sites.get(12), sites.get(13)));
		links.add(new Pair<Point, Point>(sites.get(12), sites.get(17)));

		links.add(new Pair<Point, Point>(sites.get(13), sites.get(14)));
		links.add(new Pair<Point, Point>(sites.get(13), sites.get(18)));

		links.add(new Pair<Point, Point>(sites.get(14), sites.get(19)));

		links.add(new Pair<Point, Point>(sites.get(15), sites.get(16)));
		links.add(new Pair<Point, Point>(sites.get(15), sites.get(20)));

		links.add(new Pair<Point, Point>(sites.get(16), sites.get(17)));
		links.add(new Pair<Point, Point>(sites.get(16), sites.get(21)));

		links.add(new Pair<Point, Point>(sites.get(17), sites.get(18)));
		links.add(new Pair<Point, Point>(sites.get(17), sites.get(22)));

		links.add(new Pair<Point, Point>(sites.get(18), sites.get(19)));
		links.add(new Pair<Point, Point>(sites.get(18), sites.get(23)));

		links.add(new Pair<Point, Point>(sites.get(19), sites.get(24)));

		links.add(new Pair<Point, Point>(sites.get(20), sites.get(21)));

		links.add(new Pair<Point, Point>(sites.get(21), sites.get(22)));

		links.add(new Pair<Point, Point>(sites.get(22), sites.get(23)));

		links.add(new Pair<Point, Point>(sites.get(23), sites.get(24)));
		
		notifyObserver(sites, links, temperature, cost);
		recuit();
	}

	public void stop() {
		this.isRunning = false;
	}

	public void setHashMap(HashMap<Integer, Point> sites) {
		this.sites = sites;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
}
