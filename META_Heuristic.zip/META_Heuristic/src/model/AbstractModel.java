package model;

import common.Pair;
import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import observer.Observable;
import observer.Observer;

public abstract class AbstractModel implements Observable {
	protected boolean isRunning = false;
	protected HashMap<Integer, Point> sites;
	protected List<Pair<Point, Point>> links = new ArrayList<Pair<Point, Point>>();
	protected double temperature, cost;
	private ArrayList<Observer> listObserver = new ArrayList<Observer>();
	private Random rand = new Random();

	public abstract void run();

	public abstract void stop();

	public abstract void setHashMap(HashMap<Integer, Point> sites);

	public abstract void setTemperature(double temperature);

	public abstract void setCost(double cost);

	public void addObserver(Observer obs) {
		listObserver.add(obs);
	}

	public void removeObserver() {
		listObserver = new ArrayList<Observer>();
	}

	public void notifyObserver(HashMap<Integer, Point> sites,
			List<Pair<Point, Point>> links, double temperature, double cost) {

		for (Observer obs : listObserver) {
			obs.update(sites, links, temperature, cost);
		}
	}

	protected void recuit() {
		cost = cost();
				
		TimerTask task = new TimerTask() {
			int validationCount = 0;
			double new_cost;
			double delta;
			int pt1, pt2;

			@Override
			public void run() {

				if (isRunning && (temperature > 0) &&(cost > 200)) {
					// first random point
					pt1 = rand.nextInt((24 - 0) + 1);
					
					// new state
					do {
						pt2 = rand.nextInt((24 - 0) + 1);
					} while (pt1 == pt2);
					
					//swap for getting the new cost
					swap(pt1, pt2);

					new_cost = cost();

					delta = new_cost - cost;
					
					if (stateIsValidated(delta)) {
						++validationCount;
						System.out.println("Validation count :"
							+ validationCount);

							cost = new_cost;
					}

					if (cost <= 200) {
						System.out.println("cout optimise avec succes");
					}

					temperature *= 0.999 ;
							
					System.out.println("temperature : " + temperature);
				} else {
					cancel();
				}
				
				notifyObserver(sites, links, temperature, cost);
			}
		};

		Timer timer = new Timer();

		timer.schedule(task, 0, 100);
	}

	private double cost() {
		Iterator<Pair<Point, Point>> it = links.iterator();
		double dist, cost = 0;
		Point src, dest;
		Pair<Point, Point> pair;

		while (it.hasNext()) {
			pair = it.next();
			src = pair.getL();
			dest = pair.getR();

			dist = (Math.abs(dest.x - src.x) + Math.abs(dest.y - src.y)) / 10;

			cost += dist;
		}

		return cost;
	}

	private void swap(Integer pt1, Integer pt2) {
		Point tmp = sites.get(pt1);
		sites.put(pt1, sites.get(pt2));
		sites.put(pt2, tmp);
		Iterator<Pair<Point, Point>> it = links.iterator();
		Pair<Point, Point> pair;

		while (it.hasNext()) {
			pair = it.next();
			Point ptsrc = pair.getL();
			Point ptdst = pair.getR();

			if (ptsrc.equals(sites.get(pt1)) && ptdst.equals(sites.get(pt2))) {
				pair.setL(sites.get(pt2));
				pair.setR(sites.get(pt1)); // (pt1, pt2) => (pt2, pt1)
			} else if (ptsrc.equals(sites.get(pt2))
					&& ptdst.equals(sites.get(pt1))) {
				pair.setL(sites.get(pt1)); // (pt2, pt1) => (pt1, pt2)
				pair.setR(sites.get(pt2));
			} else if (ptsrc.equals(sites.get(pt1))) {
				pair.setL(sites.get(pt2)); // (pt1, pt) => (pt2, pt) avec pt !=
											// pt1 && pt2
			} else if (ptsrc.equals(sites.get(pt2))) {
				pair.setL(sites.get(pt1)); // (pt2, pt) => (pt1, pt)
			} else if (ptdst.equals(sites.get(pt1))) {
				pair.setR(sites.get(pt2)); // (pt, pt1) => (pt, pt2)
			} else if (ptdst.equals(sites.get(pt2))) {
				pair.setR(sites.get(pt1)); // (pt, pt2) => (pt, pt1)
			}
		}
	}

	private final boolean stateIsValidated(double delta) {
		double random = rand.nextInt((1 - 0) + 1) + 0;
		double prob = Math.exp(-delta / temperature);

		if (delta < 0)
			return true;
		else
			return random > prob;
	}
}
