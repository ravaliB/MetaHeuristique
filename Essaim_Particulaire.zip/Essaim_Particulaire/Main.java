import functions.Micha;

public class Main {

	public static void main(String[] args)
	{
		Micha m5 = new Micha("Micha_2", 5, 1, 10);
		Swarm s = new Swarm(m5, 2000, 11, 200, 2.0f, 2.0f, 2.0f);
		
		s.resolve(4);
	}
	
}
