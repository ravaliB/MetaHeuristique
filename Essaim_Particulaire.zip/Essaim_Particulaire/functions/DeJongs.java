package functions;

import java.util.List;

public class DeJongs extends OptiFunc{

	public DeJongs(String name, int dim, float min_range, float max_range) {
		super(name, dim, min_range, max_range);
	}

	@Override
	public float compute(List<Float> l) {
		float sum = 0.0f;
		
		for (int i = 0; i < this.dim; i++)
		{
			float xi = l.get(i);
			sum += xi * xi;
		}
		
		return sum;
	}

}
