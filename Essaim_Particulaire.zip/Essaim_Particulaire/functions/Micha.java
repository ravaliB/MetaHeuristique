package functions;

import java.util.List;

public class Micha extends OptiFunc{

	public Micha(String name, int dim, float min_range, float max_range) {
		super(name, dim, min_range, max_range);
	}

	@Override
	public float compute(List<Float> l) {
		float sum = 0.0f;
		
		for (int i = 1; i <= this.dim; i++)
		{
			float xi = l.get(i - 1);
			float pow = 1.0f;
			float xiPow = (float)Math.sin(i * (xi * xi) / Math.PI);
			
			for (int j = 1; j <= (2 * this.dim); j++)
				pow *= xiPow;
			sum += Math.sin(xi) * pow;
		}
			
		return sum;
	}

}
