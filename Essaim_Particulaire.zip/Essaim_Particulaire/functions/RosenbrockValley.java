package functions;

import java.util.List;

public class RosenbrockValley extends OptiFunc{

	public RosenbrockValley(String name, int dim, float min_range,
			float max_range) {
		super(name, dim, min_range, max_range);
	}

	@Override
	public float compute(List<Float> l) {
		float sum = 0.0f;
		
		for (int i = 1; i < this.dim - 1; i++)
		{
			float xi = l.get(i - 1);
			float xnext = l.get(i);
			
			sum += 100.0f * Math.pow(xnext - (xi * xi), 2) + Math.pow(1 - xi, 2);
		}
		
		return sum;
	}

}
