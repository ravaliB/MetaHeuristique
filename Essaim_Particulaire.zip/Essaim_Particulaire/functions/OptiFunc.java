package functions;
import java.util.List;


public abstract class OptiFunc {
	static final int MIN_R = 0;
	static final int MAX_R = 1;
	protected String name;
	protected int dim;
	protected float [] range = new float[2];
	
	public OptiFunc(String name, int dim, float min_range, float max_range)
	{
		this.name = name;
		this.dim = dim;
		
		if (min_range > max_range)
		{
			float t= min_range;
			min_range = max_range;
			max_range = t;
		}
		
		range[MIN_R] = min_range;
		range[MAX_R] = max_range;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public int getDimension()
	{
		return dim;
	}
	
	public void setDimension(int dim)
	{
		this.dim = dim;
	}
	
	public float getRange(int i)
	{
		return range[i];
	}
	
	public void setRange(float min_range, float max_range)
	{
		if (min_range > max_range)
		{
			float t = min_range;
			min_range = max_range;
			max_range = t;
		}
		
		range[MIN_R] = min_range;
		range[MAX_R] = max_range;
	}
	
	public abstract float compute(List<Float> l);
}
