import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import functions.OptiFunc;

public class Swarm {
	private int nbParticles, nbIter, nbRun;
	private OptiFunc function;
	private List<Particle> particles = new ArrayList<Particle>();
	private List<Float> solution = new ArrayList<Float>();
	private float gbest, c1, c2, c3;
	static final int NB_ITER = 2000;
	static final int NB_RUN = 101;
	static final int NB_PARTICLES = 40;
	static final float C1 = 1.0f;
	static final float C2 = 2.0f;
	static final float C3 = 2.0f;
	private Random rand;

	public Swarm(OptiFunc f, int iter, int nbrun, int nbparticles, float c1,
			float c2, float c3) {
		function = f;
		nbIter = iter;

		if ((nbrun % 2) == 0)
			nbRun = nbrun + 1;
		else
			nbRun = nbrun;
		nbParticles = nbparticles;
		this.c1 = c1;
		this.c2 = c2;
		this.c3 = c3;
		rand = new Random(1);
	}

	public Swarm(OptiFunc f, int iter, int nbrun, int nbparticles) {
		function = f;
		nbIter = iter;

		if ((nbrun % 2) == 0)
			nbRun = nbrun + 1;
		else
			nbRun = nbrun;
		nbParticles = nbparticles;
		c1 = C1;
		c2 = C2;
		c3 = C3;
		rand = new Random(1);
	}

	public Swarm(OptiFunc f) {
		function = f;
		nbIter = NB_ITER;
		nbRun = NB_RUN;
		nbParticles = NB_PARTICLES;
		rand = new Random(0);
	}

	public Swarm() {
		nbIter = NB_ITER;
		nbRun = NB_RUN;
		nbParticles = NB_PARTICLES;
		rand = new Random(0);
	}

	public void resolve(int precision) {
		int gbest_idx = -1;
		System.out.println("Trying to minimize :");
		System.out.println(function);

		initializeSwarm();

		for (int iter = 0; iter < nbIter; iter++) {
			for (int i = 0; i < nbParticles; i++) {
				float res;

				res = particles.get(i).compute();

				if (res < gbest) {
					gbest = res;
					gbest_idx = i;
					solution = particles.get(gbest_idx).getBest();
				}
			}

			for (int i = 0; i < nbParticles; i++) {
				particles.get(i).update(particles.get(gbest_idx).getBest());
			}
		}

		printSolution(precision);
	}

	public void analysis(int precision) {
		float average = 0;
		float average_iter = 0;
		List<Float> l = new ArrayList<Float>();

		for (int run = 0; run < nbRun; run++) {
			int gbest_idx = -1;
			int nbiter = 0;
			initializeSwarm();

			for (int iter = 0; iter < nbIter; iter++) {
				for (int i = 0; i < nbParticles; i++) {
					float res;

					res = particles.get(i).compute();

					if (res < gbest) {
						gbest = res;
						gbest_idx = i;
						nbiter = iter;
						solution = particles.get(gbest_idx).getBest();
					}
				}

				for (int i = 0; i < nbParticles; i++) {
					particles.get(i).update(particles.get(gbest_idx).getBest());

				}
			}

			l.add(gbest);
			average += gbest;
			average_iter += nbiter;
			printSolution(precision);
			System.out.println("found iteration number " + nbiter);
		}

		System.out.println("-------------------------------");
		System.out.println("Average value :" + (average / nbRun));
		System.out.println("Median value :" + getMediane(l));
		System.out.println("Average Iterations number :"
				+ (average_iter / nbRun));
	}

	public OptiFunc getFunction() {
		return function;
	}

	public void setFunction(OptiFunc f) {
		function = f;
	}

	public int getNbParticles() {
		return nbParticles;
	}

	public void setNbParticles(int nb) {
		nbParticles = nb;
	}

	public int getNbIter() {
		return nbIter;
	}

	public void setNbIter(int iter) {
		nbIter = iter;
	}

	public void printSolution(int precision) {
		int i;

		System.out.print(function.getDimension() + "(");

		for (i = 0; i < function.getDimension() - 1; i++)
			System.out.println("Solution : " + solution.get(i) + ","
					+ solution.get(i) + ")" + " = " + gbest);

	}

	private void initializeSwarm() {
		gbest = Float.MAX_VALUE;
		particles.clear();

		for (int i = 0; i < nbParticles; i++) {
			particles.add(new Particle(function, c1, c2, c3));
		}
	}

	private float getMediane(List<Float> l) {
		Collections.sort(l, new Comparator<Float>() {
			@Override
			public int compare(Float f1, Float f2) {
				return f1.compareTo(f2);
			}
		});

		Iterator<Float> it = l.iterator();
		Float f;
		int i = 0;

		do {
			f = it.next();
			i++;
		} while (i < l.size() / 2);

		return f;
	}
}
