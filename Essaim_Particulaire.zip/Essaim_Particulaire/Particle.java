import java.util.ArrayList;
import java.util.List;

import functions.OptiFunc;

public class Particle {
	private List<Float> curPosition = new ArrayList<Float>();
	private List<Float> curSpeed = new ArrayList<Float>();
	private List<Float> bestPosition = new ArrayList<Float>();
	private float bestValue, c1, c2, c3;
	private OptiFunc function;

	public Particle(OptiFunc func, float c1, float c2, float c3) {
		float Down = func.getRange(0);
		float up = func.getRange(1);
		function = func;

		this.c1 = c1;
		this.c2 = c2;
		this.c3 = c3;

		for (int i = 0; i < func.getDimension(); i++) {
			curPosition.add(getRand(Down, up));
			curSpeed.add(0.0f);
		}

		bestValue = Float.MAX_VALUE;
	}

	public float compute() {
		float res;

		res = function.compute(curPosition);

		if (res < bestValue) {
			bestValue = res;
			bestPosition = curPosition;
		}

		return res;
	}

	public void update(final List<Float> gbest) {
		List<Float> newSpeed = new ArrayList<Float>();

		for (int i = 0; i < function.getDimension(); i++) {
			newSpeed.add(c1 * curSpeed.get(i) + getRand(0.0f, c2)
					* (bestPosition.get(i) - curPosition.get(i))
					+ getRand(0.0f, c3) * (gbest.get(i) - curPosition.get(i)));

			curPosition.set(i, curPosition.get(i) + newSpeed.get(i));

			if (curPosition.get(i) > function.getRange(1))
				curPosition.set(i, function.getRange(1));

			if (curPosition.get(i) < function.getRange(0))
				curPosition.set(i, function.getRange(0));
		}

		curSpeed = newSpeed;
	}

	public List<Float> getBest() {
		return bestPosition;
	}

	private float getRand(float min, float max) {
		return (float) ((max - min) * (Math.random() / 32767) + min);
	}
}
