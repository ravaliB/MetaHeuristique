package model;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import observer.Observable;
import observer.Observer;

public abstract class AbstractModel implements Observable {
	protected boolean isRunning = false;
	protected HashMap<Integer, Point> sites;
	protected HashMap<Point, Point> links = new HashMap<Point, Point>();
	protected double temperature, cost;
	private ArrayList<Observer> listObserver = new ArrayList<Observer>();

	public abstract void run();

	public abstract void stop();

	public abstract void setHashMap(HashMap<Integer, Point> sites);

	public abstract void setTemperature(double temperature);

	public abstract void setCost(double cost);

	public void addObserver(Observer obs) {
		listObserver.add(obs);
	}

	public void removeObserver() {
		listObserver = new ArrayList<Observer>();
	}

	public void notifyObserver(HashMap<Integer, Point> sites,
			HashMap<Point, Point> links, double temperature, double cost) {

		for (Observer obs : listObserver) {
			obs.update(sites, links, temperature, cost);
		}
	}

	protected void recuit() {
		/*
		 * static double T = T_INIT = 66666666 T_STEP = 0.999 T_STOP 0.000001
		 * I_STEP 10
		 */
		TimerTask task = new TimerTask() {
			int validationCount = 0, permutationcount = 0;
			double new_cost;
			double delta;
			int pt1, pt2;// , k = 0;
			Random r = new Random();

			@Override
			public void run() {
				if (isRunning && (temperature > 0) && (validationCount < 600)
						&& (permutationcount < 5000)) {
					// get current energy
					cost = cost();

					pt1 = r.nextInt((24 - 0) + 1);

					// new state
					do {
						pt2 = r.nextInt((24 - 0) + 1);
					} while (pt1 == pt2);

					swap(pt1, pt2);
					++permutationcount;

					new_cost = cost();

					delta = new_cost - cost;

					if (stateIsValidated(delta)) {
						++validationCount;
						System.out.println("Validation count :" + validationCount);
						cost = new_cost;
					} else
						swap(pt2, pt1);

					if (cost <= 200) {
						isRunning = false;
						System.out.println("cout optimise avec succes");
					}

					temperature *= 0.9999;
					/*
					 * k++;
					 * 
					 * if (k == 10) { k = 0;
					 * 
					 * notifyObserver(sites, links, temperature, cost); }
					 */

					notifyObserver(sites, links, temperature, cost);
				} else {
					cancel();
				}
			}
		};

		Timer timer = new Timer();

		timer.schedule(task, 0, 100);
	}

	private double cost() {
		Set<Point> keys = links.keySet();
		Iterator<Point> it = keys.iterator();
		double dist, cost = 0;
		Point src, dest;

		while (it.hasNext()) {
			src = it.next();
			dest = links.get(src);
			// dist = Math.sqrt(Math.pow(dest.x - src.x, 2)
			// + Math.pow(dest.y - src.y, 2)) / 10;
			dist = (Math.abs(dest.x - src.x) + Math.abs(dest.y - src.y)) / 10;

			cost += dist;
		}

		return cost;
	}

	private void swap(Integer pt1, Integer pt2) {
		Point tmp = sites.get(pt1);
		sites.put(pt1, sites.get(pt2));
		sites.put(pt2, tmp);

		Set<Point> keys = links.keySet();
		Iterator<Point> it = keys.iterator();
		HashMap<Point, Point> hashtmp = new HashMap<Point, Point>();

		while (it.hasNext()) {
			Point ptsrc = it.next();
			Point ptdst = links.get(ptsrc);

			if (ptsrc.equals(sites.get(pt1)) && ptdst.equals(sites.get(pt2)))
				hashtmp.put(sites.get(pt2), sites.get(pt1)); // (pt1, pt2) =>
																// (pt2, pt1)
			else if (ptsrc.equals(sites.get(pt2))
					&& ptdst.equals(sites.get(pt1)))
				hashtmp.put(sites.get(pt1), sites.get(pt2)); // (pt2, pt1) =>
																// (pt1, pt2)
			else if (ptsrc.equals(sites.get(pt1)))
				hashtmp.put(sites.get(pt2), ptdst); // (pt1, pt) => (pt2, pt)
													// avec pt != pt1 && pt2
			else if (ptsrc.equals(sites.get(pt2)))
				hashtmp.put(sites.get(pt1), ptdst); // (pt2, pt) => (pt1, pt)
			else if (ptdst.equals(sites.get(pt1)))
				hashtmp.put(ptsrc, sites.get(pt2)); // (pt, pt1) => (pt, pt2)
			else if (ptdst.equals(sites.get(pt2)))
				hashtmp.put(ptsrc, sites.get(pt1)); // (pt, pt2) => (pt, pt1)
			else
				hashtmp.put(ptsrc, ptdst);
		}

		links = hashtmp;
	}

	private final boolean stateIsValidated(double delta) {
		if (delta < 0)
			return true;

		double rand = Math.random();
		double prob = Math.exp(-delta / temperature);

		return rand > prob;

	}
}
