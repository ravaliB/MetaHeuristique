package model;

import java.awt.Point;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Model extends AbstractModel {
	public void run() {
		this.isRunning = true;
		Set<Integer> keys = sites.keySet();
		Iterator<Integer> it = keys.iterator();
		int dest, src, n, i;
		Random rand = new Random();

		while (it.hasNext()) {
			src = it.next();
			n = 0;

			if (isDeg(2, src))
				n = 2; //rand.nextInt((2 - 0) + 1);
			else if (isDeg(3, src))
				n = 3;//rand.nextInt((3 - 0) + 1);
			else if (isDeg(4, src))
				n = 4;//rand.nextInt((4 - 0) + 1);

			for (i = 0; i < n; i++) {
				do {
					dest = rand.nextInt((24 - 0) + 1);
				} while (dest == src);

				links.put(sites.get(src), sites.get(dest));
			}
		}

		notifyObserver(sites, links, temperature, cost);
		recuit();
	}

	public void stop() {
		this.isRunning = false;
	}

	public void setHashMap(HashMap<Integer, Point> sites) {
		this.sites = sites;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	private boolean isDeg(int n, Integer it) {
		boolean isdeg2 = (it == 0) || (it == 4) || (it == 20) || (it == 24);
		boolean isdeg3 = (it == 1) || (it == 2) || (it == 3) || (it == 5)
				|| (it == 10) || (it == 15) || (it == 9) || (it == 14)
				|| (it == 19) || (it == 21) || (it == 22) || (it == 23);
		boolean isdeg4 = (it == 6) || (it == 7) || (it == 8) || (it == 11)
				|| (it == 12) || (it == 13) || (it == 16) || (it == 17)
				|| (it == 18) || (it == 21) || (it == 22) || (it == 23);

		switch (n) {
		case 2:
			return isdeg2;
		case 3:
			return isdeg3;
		case 4:
			return isdeg4;
		default:
			System.out.println("Erreur de degr�e");
			return false;
		}

	}

}
